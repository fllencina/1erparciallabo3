
//  window.addEventListener("load",function(){
//     var boton=document.getElementById('btnGuardar');//boton=$('btnGuardar);
//     boton.addEventListener("click",agregar);
        //     localStorage.setItem("clave","valor");

        //    if(localStorage.getItem("clave")!=null) {

        //    }
        //    else{
        //     LeerGet();
        //    }
// });
var xml=new XMLHttpRequest();
window.addEventListener("load",LeerGet);
function $(id){
    return document.getElementById('id');
}
var arrayMaterias=[];

function Agregar(){
     var nombre=document.getElementById('inputNombreAgregar').value;
     var apellido=document.getElementById('inputApellidoAgregar').value;
     var telefono=document.getElementById('inputTelefonoAgregar').value;

     var fecha=document.getElementById('inputFechaAgregar').value;

    
     if(nombre=='')
     {
         nombre.className="Error";
     }
     if(apellido=='')
     {
         apellido.className="Error";
     }
     else{
        if(confirm("Esta seguro que desea agregar?")==true)
        {
            var tBody=document.getElementById('tCuerpo');
            var Fila=tBody.insertRow(0);
            var celdaNombre=Fila.insertCell(0);
            var celdaApellido=Fila.insertCell(1);
            var celdaFecha=Fila.insertCell(2);
            var celdaTelefono=Fila.insertCell(3);
            var celdaAccion=Fila.insertCell(4);
            var celdaModificar=Fila.insertCell(5);
            celdaNombre.innerHTML=nombre;
            celdaApellido.innerHTML=apellido;
            celdaFecha.innerHTML=fecha;
            celdaTelefono.innerHTML=telefono;
            celdaAccion.innerHTML="<a href=''> Borrar";
            celdaModificar.innerHTML="<a href=''> Modificar";
            
            // tBody.innerHTML=tBody.innerHTML + "<tr><td>"+nombre+"</td><td>"+apellido+"</td><td><a href=''>borrar</td></tr>"
        }
        var Persona={};
        Persona.Nombre=nombre;
        Persona.Apellido=apellido;
        Persona.Fecha=fecha;
        Persona.Telefono=telefono;
        var PersonaString=JSON.stringify(Persona);
        arrayPersonas.push(Persona);
        localStorage.setItem(Persona.Nombre+'_'+Persona.Apellido,PersonaString);
        tBody.innerHTML='';
        console.log("__________________________");
        CompletaTabla(arrayPersonas);
     }
     
}
function ModificarRegistro(){

    if(xml.readyState===4){
        if(xml.status===200)
        {
          var respuesta=xml.responseText;      
           alert(respuesta);
           var retorno=JSON.parse(respuesta);
           if(retorno.type=="ok"){
               console.log(retorno);
               document.getElementById('cargando').style.display='none';
               document.getElementById('ListaMaterias').style.display='block';  
            //    var mail=document.getElementById('email').value;
            //    mailIngresado=mail;
            //     var prefcolor=preferencias.preferencias.color;
            //    var preffont=preferencias.preferencias.font;
            //     window.location.replace("./Index.html?color="+prefcolor+"&font:"+preffont+"&email="+ mail);
           }              
       }       
       else{
           alert("error en el servidor");
             
        }
    }   
    document.getElementById('cargando').style.display='none';
    document.getElementById('ListaMaterias').style.display='block';
             
}


function cerrar()
{
    document.getElementById('divIngreso').style.display='none';
}
function cerrarModificar()
{
    document.getElementById('divVentanaMateria').style.display='none';
}
function AbrirAgregar(){
    document.getElementById('divIngreso').style.display='inline-block';
}



    //var btn= $('btn');
    //btn.addEventListener("click",LeerGet);
    // btn.addEventListener("click",enviarGet);
    
var indexSeleccionado;
function callback()
{
    if(xml.readyState===4){
        if(xml.status===200)
        {
            var respuesta=xml.responseText;      
                // alert("levanto ok");  
                //localStorage.setItem("storage",respuesta);
                //alert(localStorage.getItem("storage"));

                var listaMaterias=JSON.parse(respuesta);
                for(var i=0;i<listaMaterias.length;i++)
                { var auxiliar=JSON.stringify(listaMaterias[i]);
                    //console.log(listaPersonas[i].nombre);     
                    arrayMaterias.push(listaMaterias[i]);
                    localStorage.setItem(listaMaterias[i].nombre+'_'+listaMaterias[i].id,auxiliar);
                }
                CompletaTabla(arrayMaterias);            
        }
        
        else{
            alert("error en el servidor");
        }
    }
}
function LeerGet(){

        xml.open("GET","http://localhost:3000/materias",true);

        xml.onreadystatechange=callback;

        xml.send();

    }
    function ModifServer(){
        
        xml.open("POST","http://localhost:3000/editar",true); 
        var id=document.getElementById('idMateria').value;
        var nombreMateria=document.getElementById('nombreMateria').value;   
        var Cuatrimestre=document.getElementById('cuatrimestre').value;
        var celdaFecha=document.getElementById('fechaFinal').value;
        var radioButTrat = document.getElementsByName("turno");
        
        for (var i=0; i<radioButTrat.length; i++) {
        
        if (radioButTrat[i].checked == true) { 
            var Turno=radioButTrat[i].value;
         }
        
        }
        
        var Datos={
            id:id,
            cuatrimestre:Cuatrimestre,
            materia:nombreMateria,
            fecha:celdaFecha,
             turno:Turno
         }                
        xml.onreadystatechange=ModificarRegistro; 
        document.getElementById('cargando').style.display='block';
        document.getElementById('ListaMaterias').style.display='none';   
        document.getElementById('divVentanaMateria').style.display='none';   
        xml.send(JSON.stringify(Datos));
        
  }

function CompletaTabla(Materias)
{ 
    
    var tCuerpo=document.getElementById('tCuerpo');

    for(var i=0;i<Materias.length;i++){
        console.log(Materias[i]);
        var Fila=tCuerpo.insertRow(i);   
        Fila.addEventListener("click",MostrarVentana);  
        Fila.className='FilaTablaMateria'; 
        var id=Fila.insertCell(0)
        var CeldaNombre=Fila.insertCell(1);
        var CeldaCuatrimestre=Fila.insertCell(2);
        var CeldaFechaFinal=Fila.insertCell(3);
        var CeldaTurno=Fila.insertCell(4);   
        id.innerHTML=Materias[i].id;
        CeldaNombre.innerHTML=Materias[i].nombre;
        CeldaCuatrimestre.innerHTML=Materias[i].cuatrimestre;      
        CeldaFechaFinal.innerHTML=Materias[i].fechaFinal;
        CeldaTurno.innerHTML=Materias[i].turno;     
        tCuerpo.appendChild(Fila);
    }
    
}
function MostrarVentana()
{
    event.preventDefault();
    event.target; 
    var datosFilaMateria=event.target.parentNode;
    console.log(datosFilaMateria);
   
    var array=datosFilaMateria.children;
    var id=document.getElementById('idMateria');
       var nombreMateria=document.getElementById('nombreMateria');
     
       var Cuatrimestre=document.getElementById('cuatrimestre');
      
       var celdaFecha=document.getElementById('fechaFinal');
       var Turno=document.getElementById('turno');
    //    if(Turno[0].checked)
    //    {
    //     turno="Noche";
    //    }
    //    else if(turno[1].checked){
    //     turno="Mañana";
    //    }
          
    id.value=array[0].innerHTML;
       nombreMateria.value=array[1].innerHTML;
       Cuatrimestre.value=array[2].innerHTML;
       celdaFecha.innerText=array[3].innerHTML;
    //    Turno.checked=array[3].innerHTML;
    document.getElementById('divVentanaMateria').style.display='block';
     var btnModificar=document.getElementById('btnModificar');
     btnModificar.addEventListener("click",ModificarRegistro(array[0]));
}
    function Eliminar (event) {
        event.preventDefault();//saca valores por defecto del evento 
        event.target;//me devuelve el componente que lanza el evento
       var padre= (event.target.parentNode).parentNode;
       for(var i=0;i<arrayPersonas.length;i++)
       {
        if(arrayPersonas[i].nombre==padre.childNodes[0].innerHTML && arrayPersonas[i].apellido==padre.childNodes[1].innerHTML)
        {
            console.log(arrayPersonas.length);
            
            arrayPersonas.splice(i,1);
            console.log(arrayPersonas.length);
            localStorage.removeItem(arrayPersonas[i].nombre+'_'+arrayPersonas[i].apellido);
            //console.log(arrayPersonas[i].nombre);
            //console.log(padre.childNodes[0].innerHTML);
            //console.log("___________________________");
            //console.log(arrayPersonas[i].apellido);
            //console.log(padre.childNodes[1].innerHTML);
            //console.log("___________________________");
        }
       }
       ;
       padre.parentNode.removeChild(padre);
       
    }

     function Modificar(event) //local storage
     {
         event.preventDefault();
         event.target;     
         //console.log(event.target);
        
         var padre=((event.target).parentNode).parentNode;
         var array=padre.children;
       var tBody=document.getElementById('tCuerpoModificar');
            var Fila=tBody.insertRow(0);
            var celdaNombre=document.getElementById('inputNombre');
            var celdaApellido=document.getElementById('inputApellido');
            var celdaFecha=document.getElementById('inputFecha');
            var celdaTelefono=document.getElementById('inputTelefono');
            var celdaAccion=document.getElementById('btnGuardar');
            //var celdaModificar=Fila.insertCell(5);
            celdaNombre.placeholder=array[0].innerHTML;
            celdaApellido.placeholder=array[1].innerHTML;
            celdaFecha.placeholder=array[2].innerHTML;
            celdaTelefono.placeholder=array[3].innerHTML;
          document.getElementById('divTablaModificar').style.display='block';
          document.getElementById('modificar').style.display='block';    
    }
       