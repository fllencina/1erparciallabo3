
var arrayMaterias = [];
var MateriaOriginal = {};
var MateriaModif = {};
var xml = new XMLHttpRequest();
var rowSelect;
window.addEventListener("load", ObtenerMaterias);

function ArmarGrilla(Materias) {

    var tCuerpo = document.getElementById('tCuerpo');

    for (var i = 0; i < Materias.length; i++) {
        // console.log(Materias[i]);
        var Fila = tCuerpo.insertRow(i);
        Fila.addEventListener("dblclick",DatosMateria)
        Fila.className = 'FilaTablaMateria';
        var id = Fila.insertCell(0);
        id.style.display='none';
        var CeldaNombre = Fila.insertCell(1);
        var CeldaCuatrimestre = Fila.insertCell(2);
        var CeldaFechaFinal = Fila.insertCell(3);
        var CeldaTurno = Fila.insertCell(4);
        id.innerHTML = Materias[i].id;
        CeldaNombre.innerHTML = Materias[i].nombre;
        CeldaCuatrimestre.innerHTML = Materias[i].cuatrimestre;
        CeldaFechaFinal.innerHTML = Materias[i].fechaFinal;
        CeldaTurno.innerHTML = Materias[i].turno;
        tCuerpo.appendChild(Fila);
    }
}
function MostrarVentana() {
    var ventanaDatos = document.getElementById('divFilaDatos');
    ventanaDatos.style.display = 'block';
}
function CerrarVentana() {
    var ventanaDatos = document.getElementById('divFilaDatos');
    ventanaDatos.style.display = 'none';
}
function DatosMateria(event) {
    event.preventDefault();
    event.target;
    var padre = (event.target).parentNode;
    rowSelect=padre;
    var array = padre.children;
    var id = document.getElementById('idMateria');
    var nombreMateria = document.getElementById('inputNombre');

    var Cuatrimestre = document.getElementById('selectCuatrimestre');

    var celdaFecha = document.getElementById('inputFecha');
    // console.log(array[3].innerText);
    var Turno = document.getElementsByName('turno');
    if (array[4].innerHTML == "Mañana") {
        Turno[0].checked = true;
    }
    else if (array[4].innerHTML == "Noche") {
        Turno[1].checked = true;;
    }
    id.value = array[0].innerHTML;
     
    nombreMateria.value = array[1].innerHTML;
    Cuatrimestre.value = array[2].innerHTML;
    Cuatrimestre.disabled;
    celdaFecha.value = array[3].innerHTML;
    Materia={"id": id,
    "nombre": nombreMateria,
    "cuatrimestre": Cuatrimestre,
    "fechaFinal": celdaFecha,
    "turno": Turno}

    MostrarVentana();
}

function callback() {
    if (xml.readyState === 4) {
        if (xml.status === 200) {
            var respuesta = xml.responseText;
            // alert("levanto ok");  
            //localStorage.setItem("storage",respuesta);
            //alert(localStorage.getItem("storage"));

            var listaMaterias = JSON.parse(respuesta);
            for (var i = 0; i < listaMaterias.length; i++) {
                var auxiliar = JSON.stringify(listaMaterias[i]);
                //console.log(listaPersonas[i].nombre);     
                arrayMaterias.push(listaMaterias[i]);
                localStorage.setItem(listaMaterias[i].nombre + '_' + listaMaterias[i].id, auxiliar);
            }
            ArmarGrilla(arrayMaterias);
        }

        else {
            alert("error en el servidor");
        }
    }
}
function ObtenerMaterias() {
    xml.open("GET", "http://localhost:3000/materias", true);

    xml.onreadystatechange = callback;

    xml.send();
}

function ModificarRegistro() {

    if (xml.readyState === 4) {
        if (xml.status === 200) {
            var respuesta = xml.responseText;
             console.log("respuesta:" + respuesta);
            var retorno = JSON.parse(respuesta);
            if (retorno.type == "ok") {
                for(var i=0;i<arrayMaterias.length;i++){
                   if(Materia.id==arrayMaterias[i]){
                    arrayMaterias.slice(i,1);
                   }
                } 
                arrayMaterias.push(MateriaModif);
                console.log(rowSelect);
                var hijos=rowSelect.children;
                for(var i=0;i<hijos.length;i++)
                {         
                    rowSelect.removeChild(hijos[i]);
                    if(hijos.length>0)
                    {
                        i--;
                    } 
                    console.log(rowSelect);
                }

                rowSelect.addEventListener("dblclick",DatosMateria);
                var id=MateriaModif.id;
                var nombre=MateriaModif.nombre;
                var cuatrimestre=MateriaModif.cuatrimestre;
                var fechaFinal=MateriaModif.fechaFinal;
                var turno=MateriaModif.turno;

                // var celdaID=rowSelect.insertCell(0);
                var celdaNombre= rowSelect.insertCell();
                var CeldaCuatrimestre=rowSelect.insertCell(1);
                var celdaFecha=rowSelect.insertCell(2);
                var CeldaTurno=rowSelect.insertCell(3);
                  
                

                //celdaID.appendChild(id);
                celdaNombre.innerHTML=nombre;
                CeldaCuatrimestre.innerHTML=cuatrimestre;
                celdaFecha.innerHTML=fechaFinal;
                CeldaTurno.innerHTML=turno;

                document.getElementById('cargando').style.display = 'none';
                document.getElementById('divContieneGrilla').style.display = 'block';
                document.getElementById('divFilaDatos').style.display = 'block';
                CerrarVentana();
            }
        }
        else {
            alert("error en el servidor");
        }
    }
    // document.getElementById('cargando').style.display = 'none';
    // document.getElementById('ListaMaterias').style.display = 'block';

}
function ModificarMateria() {

    var id = document.getElementById('idMateria').value;
    var nombreMateria = document.getElementById('inputNombre').value;
    var Cuatrimestre = document.getElementById('selectCuatrimestre').value;
    var celdaFecha = document.getElementById('inputFecha').value;
    var radioButTrat = document.getElementsByName("turno");

    var Turno;
    for (var i = 0; i < radioButTrat.length; i++) {

        if (radioButTrat[i].checked == true) {
             Turno = radioButTrat[i].value;
        }
    }
    var Datos = {
        "id": id,
        "nombre": nombreMateria,
        "cuatrimestre": Cuatrimestre,
        "fechaFinal": celdaFecha,
        "turno": Turno
    }
    MateriaModif=Datos;
    document.getElementById('cargando').style.display = 'block';
    document.getElementById('divContieneGrilla').style.display = 'none';
    document.getElementById('divFilaDatos').style.display = 'none';
   
    xml.open("POST", "http://localhost:3000/editar", true);
    xml.setRequestHeader("Content-Type", "application/json");  
    xml.onreadystatechange = ModificarRegistro;
    xml.send(JSON.stringify(Datos));
}

function EliminarRegistro()
{
    if (xml.readyState === 4) {
        if (xml.status === 200) {
            var respuesta = xml.responseText;
            console.log(respuesta);
            if(JSON.parse(respuesta).type==="ok"){
                rowSelect.parentNode.removeChild(rowSelect);
            }
            for(var i=0;i<arrayMaterias.length;i++){
                if(MateriaModif.id==arrayMaterias[i]){
                 arrayMaterias.slice(i,1);
                }
             } 
              
            document.getElementById('cargando').style.display = 'none';
            document.getElementById('divContieneGrilla').style.display = 'block';
            document.getElementById('divFilaDatos').style.display = 'block';
            CerrarVentana();
        }
        else{
            alert("Error en servidor funcion eliminar");
        }
    }
   
}
function Eliminar()
{
    var id=document.getElementById('idMateria').value;
    var Datos={
        "id":id
    }
    MateriaModif=Datos;

    document.getElementById('cargando').style.display = 'block';
    document.getElementById('divContieneGrilla').style.display = 'none';
    document.getElementById('divFilaDatos').style.display = 'none';
    xml.open("POST", "http://localhost:3000/eliminar", true);
    xml.setRequestHeader("Content-Type", "application/json");
    xml.onreadystatechange = EliminarRegistro;
    xml.send(JSON.stringify(Datos));
}

